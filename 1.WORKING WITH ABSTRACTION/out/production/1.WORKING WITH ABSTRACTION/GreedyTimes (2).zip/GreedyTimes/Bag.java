package GreedyTimes;

import java.util.ArrayList;
import java.util.List;

public class Bag {
    private long maxWeight;
    private long weight;
    private Item gold;
    private List<Item> gems;
    private List<Item> cash;
    private long amountOfGold;
    private long amountOfgems;
    private long amountOfCash;

    public Bag(long maxWeight) {
        this.maxWeight = maxWeight;
        this.weight = 0;
        this.gold = new Item("Gold",0);
        this.gems = new ArrayList<>();
        this.cash = new ArrayList<>();
        this.amountOfGold = -1;
        this.amountOfgems = 0;
        this.amountOfCash = 0;
    }

    public void setAmountOfGold(long amountOfGold) {
        this.amountOfGold = amountOfGold;
    }

    public void setAmountOfgems(long amountOfgems) {
        this.amountOfgems = amountOfgems;
    }

    public void setAmountOfCash(long amountOfCash) {
        this.amountOfCash = amountOfCash;
    }

    public long getMaxWeight() {
        return maxWeight;
    }

    public long getWeight() {
        return weight;
    }

    public Item getGold() {
        return gold;
    }

    public List<Item> getGems() {
        return gems;
    }

    public List<Item> getCash() {
        return cash;
    }

    public long getAmountOfGold() {
        return amountOfGold;
    }

    public long getAmountOfgems() {
        return amountOfgems;
    }

    public long getAmountOfCash() {
        return amountOfCash;
    }

}
