
package GreedyTimes;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        long bagCapacity = Long.parseLong(scanner.nextLine());
        String[] safeContent = scanner.nextLine().split("\\s+");
        Bag bag = new Bag(bagCapacity);

        for (int i = 0; i < safeContent.length; i += 2) {
            String itemName = safeContent[i];
            long itemValue = Long.parseLong(safeContent[i + 1]);

            if (itemName.length() == 3) {
                Item item = new Item(itemName, itemValue);
                if (bag.getAmountOfgems()>=bag.getAmountOfCash()+itemValue){
                    bag.getCash().add(item);
                    bag.setAmountOfCash(bag.getAmountOfCash() + itemValue);
                }
            } else if (itemName.toLowerCase().endsWith("gem")) {
                Item item = new Item(itemName, itemValue);
                if (bag.getGold().getValue()>=bag.getAmountOfgems()+itemValue){
                    bag.getGems().add(item);
                    bag.setAmountOfgems(bag.getAmountOfgems() + itemValue);
                }
            } else if (itemName.toLowerCase().equals("gold")) {
                bag.getGold().setValue(bag.getGold().getValue()+itemValue);
                bag.setAmountOfGold(bag.getAmountOfGold()+itemValue);
            }
        }

        if (bag.getAmountOfGold()!=0){
            System.out.printf("<Gold> $%s%n",bag.getGold().getValue());
            System.out.println(bag.getGold().toString());
        }
        if (bag.getGems().size()>0){
            System.out.printf("<Gem> $%s%n",bag.getAmountOfgems());
            bag.getGems().sort(Comparator.comparing(Item::getName).reversed().thenComparing(Item::getValue));
            for (Item item:bag.getGems()
                 ) {
                System.out.println(item.toString());
            }
        }
        if (bag.getCash().size()>0){
            System.out.printf("<Cash> $%s%n",bag.getAmountOfCash());
            bag.getCash().sort(Comparator.comparing(Item::getName).reversed().thenComparing(Item::getValue));
            for (Item item:bag.getCash()
                 ) {
                System.out.println(item.toString());
            }
        }
    }
}