
package GreedyTimes;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        long bagCapacity = Long.parseLong(scanner.nextLine());
        String[] safeContent = scanner.nextLine().split("\\s+");

        LinkedHashMap<String, List<Item>> bag = new LinkedHashMap<>();
        long goldInBag = 0;
        long gemsInBag = 0;
        long cashInBag = 0;
        long bagValue = goldInBag + gemsInBag + cashInBag;

        for (int i = 0; i < safeContent.length; i += 2) {
            String itemName = safeContent[i];
            long itemValue = Long.parseLong(safeContent[i + 1]);

            String type = "";

            if (itemName.length() == 3) {
                type = "Cash";
            } else if (itemName.toLowerCase().endsWith("gem")) {
                type = "Gem";
            } else if (itemName.toLowerCase().equals("gold")) {
                type = "Gold";
            }

            if (type.equals("")) {
                continue;
            } else if (bagCapacity < bagValue + itemValue) {
                continue;
            }
            Item item = new Item(itemName, type, itemValue);
            if (!bag.containsKey(type)) {
                bag.put((type), new ArrayList<>());
            }
            switch (type) {
                case "Gem":
                    if (goldInBag >= gemsInBag + itemValue) {
                        bag.get(type).add(item);
                        gemsInBag += itemValue;
                    }
                    break;
                case "Cash":
                    if (gemsInBag >= cashInBag + itemValue) {
                        bag.get(type).add(item);
                        cashInBag += itemValue;
                    }
                    break;
                case "Gold":
                    if (bag.get(type).size() == 0) {
                        bag.get(type).add(item);
                    }
                    goldInBag += itemValue;
                    break;
            }

        }
        bag.get("Gold").get(0).setValue(goldInBag);
        Map<String, Long> totalAmounts = new LinkedHashMap<>();
        totalAmounts.put("Gold", goldInBag);
        totalAmounts.put("Gem", gemsInBag);
        totalAmounts.put("Cash", cashInBag);

        totalAmounts.entrySet().stream().sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue())).forEach(e -> {
            if (bag.get(e.getKey()).size() > 0){
                System.out.printf("<%s> $%s%n", e.getKey(), e.getValue());
                bag.get(e.getKey()).sort(Comparator.comparing(Item::getName).reversed().thenComparing(Item::getValue));
                for (Item item : bag.get(e.getKey())
                ) {
                    System.out.printf("##%s - %s%n", item.getName(), item.getValue());
                }
            }
        });
    }
}