package TrafficLights;

public enum Signal {
    RED,
    GREEN,
    YELLOW;
}
