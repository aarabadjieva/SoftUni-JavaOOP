public class Lembas extends Food {
    public Lembas(int happinesPoints) {
        super(happinesPoints);
    }
}
