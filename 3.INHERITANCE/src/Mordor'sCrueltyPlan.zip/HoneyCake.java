public class HoneyCake extends Food {
    public HoneyCake(int happinesPoints) {
        super(happinesPoints);
    }
}
