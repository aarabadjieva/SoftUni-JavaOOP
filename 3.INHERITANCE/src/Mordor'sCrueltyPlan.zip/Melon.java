public class Melon extends Food {
    public Melon(int happinesPoints) {
        super(happinesPoints);
    }
}
