public class Mushrooms extends Food {
    public Mushrooms(int happinesPoints) {
        super(happinesPoints);
    }
}
