public class Food {
    private int happinesPoints;

    public Food(int happinesPoints) {
        this.happinesPoints = happinesPoints;
    }

    public int getHappinesPoints() {
        return this.happinesPoints;
    }
}
