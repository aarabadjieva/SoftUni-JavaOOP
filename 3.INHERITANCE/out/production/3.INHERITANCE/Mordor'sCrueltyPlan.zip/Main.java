import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, Food> foods = new HashMap<>(){{
            put("cram", new Cram(2));
            put("lembas", new Lembas(3));
            put("apple", new Apple(1));
            put("melon", new Melon(1));
            put("honeycake", new HoneyCake(5));
            put("mushrooms", new Mushrooms(-10));
        }};
        Gandalf gandalf = new Gandalf();
        String[] inputFoods = scanner.nextLine().split("\\s");
        for (String food:inputFoods
             ) {
            String happinesPoints = "-1";
            if (foods.containsKey(food.toLowerCase())){
                happinesPoints = String.valueOf(foods.get(food.toLowerCase()).getHappinesPoints());
            }
            gandalf.eatFood(happinesPoints);
        }

        System.out.println(gandalf.getFoodPoints());
        System.out.println(gandalf.getMood());
    }
}
