public class Cram extends Food {
    public Cram(int happinesPoints) {
        super(happinesPoints);
    }
}
