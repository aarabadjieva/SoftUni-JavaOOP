public class Gandalf {
    private int foodPoints;


    public Gandalf() {
        this.foodPoints = 0;
    }

    public void eatFood(String food){
        int happinesPoints = Integer.parseInt(food);
        this.foodPoints +=happinesPoints;
    }

    public int getFoodPoints(){
        return this.foodPoints;
    }

    public String getMood(){
        String mood = "";
        if (this.foodPoints<-5){
            mood = "Angry";
        }else if (this.foodPoints<0){
            mood = "Sad";
        }else if (this.foodPoints<15){
            mood = "Happy";
        }else {
            mood = "JavaScript";
        }
        return mood;
    }
}
