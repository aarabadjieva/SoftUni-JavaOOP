public class Apple extends Food {
    public Apple(int happinesPoints) {
        super(happinesPoints);
    }
}
