package cresla.core;

import cresla.entities.modules.CooldownSystem;
import cresla.entities.modules.CryogenRod;
import cresla.entities.modules.HeatProcessor;
import cresla.entities.reactors.CryoReactor;
import cresla.entities.reactors.HeatReactor;
import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;
import cresla.interfaces.Manager;
import cresla.interfaces.Module;
import cresla.interfaces.Reactor;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ManagerImpl implements Manager {

    private static int id;
    private Map<Integer, Reactor> reactors;
    private Map<Integer, Module> modules;
    private int cryoReactorsCount;
    private int heatReactorsCount;
    private int energyModulesCount;
    private int absorbingModulesCount;


    public ManagerImpl() {
        ManagerImpl.id = 0;
        this.reactors = new LinkedHashMap<>();
        this.modules = new LinkedHashMap<>();
        this.cryoReactorsCount = 0;
        this.heatReactorsCount = 0;
        this.absorbingModulesCount =0;
        this.energyModulesCount = 0;
    }

    @Override
    public String reactorCommand(List<String> arguments) {
        int id = ++ManagerImpl.id;
        String type = arguments.get(0);
        int additionalParam = Integer.parseInt(arguments.get(1));
        int capacity = Integer.parseInt(arguments.get(2));
        Reactor reactor;
        if (type.equals("Cryo")) {
            reactor = new CryoReactor(id, additionalParam, capacity);
            this.cryoReactorsCount++;
        } else {
            reactor = new HeatReactor(id, additionalParam, capacity);
            this.heatReactorsCount++;
        }
        this.reactors.put(id, reactor);

        return String.format("Created %s Reactor – %d", type, id);
    }

    @Override
    public String moduleCommand(List<String> arguments) {
        int id = ++ManagerImpl.id;
        int reactorID = Integer.parseInt(arguments.get(0));
        String type = arguments.get(1);
        int additionalParam = Integer.parseInt(arguments.get(2));
        Module module = null;
        switch (type) {
            case "CryogenRod":
                module = new CryogenRod(id, additionalParam);
                this.reactors.get(reactorID).addEnergyModule((EnergyModule) module);
                this.energyModulesCount++;
                break;
            case "HeatProcessor":
                module = new HeatProcessor(id, additionalParam);
                this.reactors.get(reactorID).addAbsorbingModule((AbsorbingModule) module);
                this.absorbingModulesCount++;
                break;
            case "CooldownSystem":
                module = new CooldownSystem(id, additionalParam);
                this.reactors.get(reactorID).addAbsorbingModule((AbsorbingModule) module);
                this.absorbingModulesCount++;
                break;
        }
        this.modules.put(id, module);
        return String.format("Added %s - %d to Reactor - %d", type, id, reactorID);
    }

    @Override
    public String reportCommand(List<String> arguments) {
        int neededID = Integer.parseInt(arguments.get(0));
        String result = "";
      //  if (this.reactors.containsKey(neededID)) {
      //      result = this.reactors.get(neededID).toString();
      //  } else {
      //      result = this.modules.get(neededID).toString();
      //  }
        return result;
    }


    @Override
    public String exitCommand(List<String> arguments) {
        return this.toString();
    }

    @Override
    public String toString() {
        long totalEnergyOutput = 0;
        long totalHeatAbsorbing = 0;
        for (Reactor reactor : this.reactors.values()
        ) {
            totalEnergyOutput += reactor.getTotalEnergyOutput();
            totalHeatAbsorbing += reactor.getTotalHeatAbsorbing();
        }
        return String.format("Cryo Reactors: %d%n" +
                        "Heat Reactors: %d%n" +
                        "Energy Modules: %d%n" +
                        "Absorbing Modules: %d%n" +
                        "Total Energy Output: %d%n" +
                        "Total Heat Absorbing: %d%n", this.cryoReactorsCount,
                this.heatReactorsCount, this.energyModulesCount,
                this.absorbingModulesCount, totalEnergyOutput,
                totalHeatAbsorbing);
    }
}
