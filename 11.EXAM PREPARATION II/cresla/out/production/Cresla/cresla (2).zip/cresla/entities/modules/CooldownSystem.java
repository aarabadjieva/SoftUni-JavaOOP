package cresla.entities.modules;

public class CooldownSystem extends AbsorbingModuleImpl {
    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }

}
