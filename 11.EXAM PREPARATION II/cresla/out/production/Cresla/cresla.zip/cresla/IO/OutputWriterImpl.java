package cresla.IO;

import cresla.interfaces.OutputWriter;

public class OutputWriterImpl implements OutputWriter {
    @Override
    public void write(String output) {

    }

    @Override
    public void writeLine(String output) {

    }
}
