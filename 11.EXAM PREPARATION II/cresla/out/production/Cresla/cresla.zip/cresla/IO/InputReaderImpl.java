package cresla.IO;

import cresla.interfaces.InputReader;

public class InputReaderImpl implements InputReader {
    @Override
    public String readLine() {
        return null;
    }
}
