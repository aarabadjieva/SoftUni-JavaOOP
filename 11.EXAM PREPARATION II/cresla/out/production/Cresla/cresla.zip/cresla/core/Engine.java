package cresla.core;

import cresla.IO.InputReaderImpl;
import cresla.IO.OutputWriterImpl;
import cresla.interfaces.InputReader;
import cresla.interfaces.Manager;
import cresla.interfaces.OutputWriter;

public class Engine {
    private Manager manager;
    private InputReader inputReader;
    private OutputWriter outputWriter;

    public Engine() {
        this.manager = new ManagerImpl();
        this.inputReader = new InputReaderImpl();
        this.outputWriter = new OutputWriterImpl();
    }

    public void run(){

    }
}
