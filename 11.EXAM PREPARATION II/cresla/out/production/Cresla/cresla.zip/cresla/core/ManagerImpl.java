package cresla.core;

import cresla.interfaces.Manager;
import cresla.interfaces.Reactor;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ManagerImpl implements Manager {

    private Map<Integer, Reactor> reactors;

    public ManagerImpl() {
        this.reactors = new LinkedHashMap<>();
    }

    @Override
    public String reactorCommand(List<String> arguments) {
        return null;
    }

    @Override
    public String moduleCommand(List<String> arguments) {
        return null;
    }

    @Override
    public String reportCommand(List<String> arguments) {
        return null;
    }

    @Override
    public String exitCommand(List<String> arguments) {
        return null;
    }
}
