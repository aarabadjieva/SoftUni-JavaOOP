package cresla.entities.reactors;

public class HeatReactor extends ReactorImpl {
    private int heatReductionIndex;

    public HeatReactor(int id, int capacity, int heatReductionIndex) {
        super(id, capacity);
        this.heatReductionIndex = heatReductionIndex;
    }
}
