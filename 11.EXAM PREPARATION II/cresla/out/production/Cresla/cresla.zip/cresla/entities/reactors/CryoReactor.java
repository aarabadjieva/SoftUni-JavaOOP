package cresla.entities.reactors;

public class CryoReactor extends ReactorImpl{
    private int cryoProductionindex;

    CryoReactor(int id, int capacity, int cryoProductionindex) {
        super(id, capacity);
        this.cryoProductionindex = cryoProductionindex;
    }
}
