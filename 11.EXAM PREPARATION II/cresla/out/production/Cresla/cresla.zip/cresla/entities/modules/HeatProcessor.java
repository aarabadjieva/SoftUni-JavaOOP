package cresla.entities.modules;

public class HeatProcessor extends AbsorbingModuleImpl {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
