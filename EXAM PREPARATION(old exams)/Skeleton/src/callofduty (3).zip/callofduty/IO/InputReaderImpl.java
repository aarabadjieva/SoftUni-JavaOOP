package callofduty.IO;

public class InputReaderImpl implements callofduty.interfaces.InputReader {
    @Override
    public String readLine() {
        return null;
    }
}
