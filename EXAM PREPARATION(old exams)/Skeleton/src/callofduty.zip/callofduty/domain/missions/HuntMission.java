package callofduty.entities.missions;

public class HuntMission extends MissionImpl {
    protected HuntMission(String id, double rating, double bounty) {
        super(id, rating, bounty);
    }
}
