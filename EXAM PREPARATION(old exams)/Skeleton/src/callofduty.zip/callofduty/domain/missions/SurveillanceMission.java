package callofduty.entities.missions;

public class SurveillanceMission extends MissionImpl{
    protected SurveillanceMission(String id, double rating, double bounty) {
        super(id, rating, bounty);
    }
}
