package callofduty.IO;

import callofduty.interfaces.OutputWriter;

public class OutputWriterImpl implements OutputWriter {
    @Override
    public void print(String output) {

    }

    @Override
    public void println(String output) {

    }
}
