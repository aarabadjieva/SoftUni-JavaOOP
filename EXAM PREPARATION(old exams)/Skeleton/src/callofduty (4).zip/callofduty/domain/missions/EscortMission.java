package callofduty.domain.missions;

public class EscortMission extends MissionImpl {
    protected EscortMission(String id, double rating, double bounty) {
        super(id, rating, bounty);
    }

}
