package exceptions;

public class RaceAlreadyExistException extends Exception {
    public RaceAlreadyExistException(String message) {
        super(message);
    }
}
