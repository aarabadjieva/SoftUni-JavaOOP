package exceptions;

public class DuplicateModelException extends Exception {
    public DuplicateModelException() {
        super();
    }
}
