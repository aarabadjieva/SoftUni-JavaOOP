package hell.core;

import hell.interfaces.InputReader;

import java.util.Scanner;

public class InputReaderImpl implements InputReader {


    @Override
    public String readLine() {
        return null;
    }
}
