public class Box {
    private double length;
    private double width;
    private double heigth;

    public Box(double length, double width, double heigth) {
        this.length = length;
        this.width = width;
        this.heigth = heigth;
    }

    public double calculateSurfaceArea(){
        return 2*this.length*this.width + 2*this.length*this.heigth
                + 2*this.width*this.heigth;
    }

    public double calculateLateralSurfaceArea(){
        return 2*this.length*this.heigth + 2*this.width*this.heigth;
    }

    public double calculateVolume(){
        return this.length*this.width*this.heigth;
    }
}
