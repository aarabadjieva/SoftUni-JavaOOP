package InterfacePerson;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        List<Birthable> creatures = new ArrayList<>();
        while(!line.equals("End")){
            String[] info = line.split("\\s");
            switch (info[0]){
                case "Citizen":
                    Citizen citizen = new Citizen(info[1],Integer.parseInt(info[2]),info[3],info[4]);
                    creatures.add(citizen);
                    break;
                case "Pet":
                    Pet pet = new Pet(info[1],info[2]);
                    creatures.add(pet);
                    break;
                case "Robot":
                    Robot robot = new Robot(info[1],info[2]);
                    break;
            }
            line = scanner.nextLine();
        }
        line = scanner.nextLine();
        for (Birthable creature:creatures
             ) {
            String birthYear = creature.getBirthDate().split("/")[2];
            if (birthYear.equals(line)){
                System.out.println(creature.getBirthDate());
            }
        }
    }
}
