package MilitaryElite.Interfaces;

import MilitaryElite.Repair;

public interface Engineer extends SpecialisedSoldier {
    void addRepair(Repair repair);
}
