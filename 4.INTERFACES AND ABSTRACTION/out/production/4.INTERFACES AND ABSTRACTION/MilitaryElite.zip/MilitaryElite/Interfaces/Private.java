package MilitaryElite.Interfaces;

import MilitaryElite.Interfaces.Soldier;

public interface Private extends Soldier {
    double getSalary();
}
