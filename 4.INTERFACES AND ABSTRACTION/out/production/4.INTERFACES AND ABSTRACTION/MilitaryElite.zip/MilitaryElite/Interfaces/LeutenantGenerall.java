package MilitaryElite.Interfaces;

import MilitaryElite.PrivateImpl;

public interface LeutenantGenerall extends Private {
    void addPrivate(PrivateImpl privateSoldier);
}
