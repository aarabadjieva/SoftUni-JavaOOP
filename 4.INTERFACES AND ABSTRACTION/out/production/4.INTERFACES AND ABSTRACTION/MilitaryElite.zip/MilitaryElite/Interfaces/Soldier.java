package MilitaryElite.Interfaces;

public interface Soldier {
    String print();
    int getId();
    String getFirstName();
    String getLastName();

}
