package MilitaryElite.Interfaces;

public interface SpecialisedSoldier extends Private {
    void setCorps(String corps);
    String getCorps();
}
